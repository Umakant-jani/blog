---
layout: home
title: "Recent Posts"
tags: [Jekyll, theme, responsive, blog, template]
image:
  feature: typewriter.jpg
---